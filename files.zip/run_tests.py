"""
run_tests.py — Corredor de tests de Deudix.
Ejecutar con doble-click o desde consola:
  C:\Users\gmgra\AppData\Local\Python\bin\python.exe run_tests.py
"""
import subprocess
import sys
import os

PYTHON = r"C:\Users\gmgra\AppData\Local\Python\bin\python.exe"

# Directorio raiz del proyecto (donde esta este archivo)
ROOT = os.path.dirname(os.path.abspath(__file__))
TESTS = os.path.join(ROOT, "tests")

print()
print("=" * 50)
print("  DEUDIX - Suite de tests de regresion")
print("=" * 50)
print()
print(f"Python : {PYTHON}")
print(f"Proyecto: {ROOT}")
print(f"Tests  : {TESTS}")
print()

# Instalar pytest si no esta
print("Verificando pytest...")
subprocess.run([PYTHON, "-m", "pip", "install", "pytest", "pytest-cov", "-q"],
               check=False)
print()

# Correr los tests
print("Corriendo tests...")
print("-" * 50)
result = subprocess.run(
    [PYTHON, "-m", "pytest", TESTS, "-v", "--tb=short", "--no-header"],
    cwd=ROOT,
)
print("-" * 50)
print()
if result.returncode == 0:
    print("  TODOS LOS TESTS PASARON")
else:
    print("  HAY TESTS FALLANDO - revisar arriba")
print("=" * 50)
print()
input("Presiona Enter para cerrar...")
